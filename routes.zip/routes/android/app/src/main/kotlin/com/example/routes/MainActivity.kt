package com.example.routes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
